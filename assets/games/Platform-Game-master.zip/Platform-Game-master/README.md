# Platform Game (Codename: The Jumping Dead)
An HTML/JavaScript platformer created using [W3 Schools' Game Tutorial](http://www.w3schools.com/graphics/game_canvas.asp ) as a learning guide. The game uses the HTML canvas element to support functionality.

The goal is to evade all the bad guys!

### Help Wanted
New contributors are welcome to work on this game, as it's only in the early stages and needs a lot of additional features. Please read the [CONTRIBUTING](https://github.com/EdwardDunn/Platform-Game/blob/master/CONTRIBUTING.md) document if you'd like to contribute.

## [Play Game](https://edwarddunn.github.io/Platform-Game/index.html)

### Licenses
This project is filed under the MIT license.
